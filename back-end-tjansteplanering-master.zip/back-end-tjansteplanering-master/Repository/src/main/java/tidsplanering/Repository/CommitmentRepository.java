package tidsplanering.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tidsplanering.Domain.Commitment;
import tidsplanering.Domain.Staff;

import java.util.List;
import java.util.Optional;

@Repository
public interface CommitmentRepository extends JpaRepository<Commitment, Long> {

    Optional<Commitment> findById(Long id);

    List<Commitment> findByStaffId(Long staff_id);

    List<Commitment> findByTimeScopeStartingWith(String year);

    List<Commitment> findByStaffIdAndTimeScopeStartingWith(Long staffId, String year);

    // Find commitments with endRange on or after the selected year
    List<Commitment> findAllByStaffId(Long staffId);




}
