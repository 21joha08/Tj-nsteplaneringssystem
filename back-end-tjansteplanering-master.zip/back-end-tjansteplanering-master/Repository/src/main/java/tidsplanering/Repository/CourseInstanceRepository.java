package tidsplanering.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tidsplanering.Domain.CourseInstance;
import tidsplanering.Domain.Staff;
import tidsplanering.Domain.Task;

import java.util.List;
import java.util.Optional;

@Repository
public interface CourseInstanceRepository extends JpaRepository<CourseInstance, Long> {

    Optional<CourseInstance> findById(Long id);

    List<CourseInstance> findAllByTaskIn(List<Task> tasks);

    List<CourseInstance> findByTask_TimescopeStartingWith(String year);

}
