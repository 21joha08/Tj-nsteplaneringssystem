package tidsplanering.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tidsplanering.Domain.CourseInstance;
import tidsplanering.Domain.Curriculum;

import java.util.Optional;

@Repository
public interface CurriculumRepository extends JpaRepository<Curriculum, Long> {

    Optional<Curriculum> findById(Long id);

}
