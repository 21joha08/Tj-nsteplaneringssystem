package tidsplanering.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tidsplanering.Domain.YearGroup;

import java.util.Optional;

@Repository
public interface YearGroupRepository extends JpaRepository<YearGroup, Long> {
    Optional<YearGroup> findById(Long id);

}
