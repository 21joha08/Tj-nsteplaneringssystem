package tidsplanering.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tidsplanering.Domain.CourseInstance;
import tidsplanering.Domain.Surcharges;

import java.util.Optional;

public interface SurchargesRepository extends JpaRepository<Surcharges, Long> {

    Optional<Surcharges> findById(Long id);

}

