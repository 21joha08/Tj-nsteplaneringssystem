package tidsplanering.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tidsplanering.Domain.Commitment;
import tidsplanering.Domain.Contract;

import java.util.List;
import java.util.Optional;

public interface ContractRepository extends JpaRepository<Contract, Long> {

    Optional<Contract> findById(Long id);

    List<Contract> findByStaffId(Long staffId);

    List<Contract> findByStaffIdAndTimeScopeStartingWith(Long staffId, String year);

    List<Contract> findByStaff_AffiliationCode(String affiliationCode);

}
