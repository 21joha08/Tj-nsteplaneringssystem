package tidsplanering.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tidsplanering.Domain.CourseInstance;
import tidsplanering.Domain.Project;
import tidsplanering.Domain.Task;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> {

    Optional<Project> findById(Long id);

    List<Project> findByTask_TimescopeStartingWith(String year);

    List<Project> findAllByTaskIn(List<Task> tasks);
}
