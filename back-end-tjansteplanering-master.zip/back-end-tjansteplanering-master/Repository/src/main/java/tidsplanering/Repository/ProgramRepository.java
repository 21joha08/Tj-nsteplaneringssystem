package tidsplanering.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tidsplanering.Domain.Program;
import tidsplanering.Domain.Staff;

import java.util.Optional;

@Repository
public interface ProgramRepository extends JpaRepository<Program, Long> {
    Optional<Program> findById(Long id);

}
