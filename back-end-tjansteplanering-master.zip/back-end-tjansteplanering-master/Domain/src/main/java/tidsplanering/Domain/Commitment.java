package tidsplanering.Domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Commitment implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "staff_id")
    private Staff staff;

    @ManyToOne
    @JoinColumn(name = "task_id")
    private Task task;

    @Column(nullable = false)
    private int timeResource;

    @Column
    private String note;

    @Column(nullable = false)
    private boolean responsible;

    @Column(nullable = false)
    private boolean examiner;

    @Column
    private String timeScope;

    @Column
    private String division;

    @Column
    private String project;

    @Column
    private String financier;

    @Column
    private String activity;

    public Long getId() {
        return id;
    }

    public Staff getStaff() {
        return staff;
    }

    public Task getTask() {
        return task;
    }

    public int getTimeResource() {
        return timeResource;
    }
    public String getNote() {
        return note;
    }

    public boolean getResponsible() {
        return responsible;
    }

    public boolean getExaminer() {
        return examiner;
    }

    public String getTimeScope() {
        return timeScope;
    }

    public String getDivision() {
        return division;
    }

    public String getProject() {
        return project;
    }

    public String getFinancier() {
        return financier;
    }

    public String getActivity() {
        return activity;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public void setTask(Task task) {
        this.task = task;
    }

    public void setTimeResource(int timeResource) {
        this.timeResource = timeResource;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public void setResponsible(boolean responsible) {
        this.responsible = responsible;
    }

    public void setExaminer(boolean examiner) {
        this.examiner = examiner;
    }

    public void setTimeScope(String timeScope) {
        this.timeScope = timeScope;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public void setFinancier(String financier) {
        this.financier = financier;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }
}
