package tidsplanering.Domain;

import java.util.List;

public class Department {

    private String name;

    private List<Double> workLoad;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Double> getWorkLoad() {
        return workLoad;
    }

    public void setWorkLoad(List<Double> workLoad) {
        this.workLoad = workLoad;
    }

}
