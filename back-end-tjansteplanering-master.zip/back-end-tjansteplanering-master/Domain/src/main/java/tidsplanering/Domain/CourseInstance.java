package tidsplanering.Domain;

import javax.persistence.*;
import java.io.Serializable;
@Entity
public class CourseInstance implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String courseInstanceId;

    private int year;

    private int week;

    private int students;

    private int fstsStudents;

    private double speed;

    @ManyToOne
    private Course course;

    @OneToOne
    @JoinColumn(name = "task_id")
    private Task task;

    public Long getId() {
        return id;
    }

    public String getCourseInstanceId() {
        return courseInstanceId;
    }

    public int getYear() {
        return year;
    }

    public int getWeek() {
        return week;
    }

    public int getStudents() {
        return students;
    }

    public int getFstsStudents() {
        return fstsStudents;
    }

    public double getSpeed() {
        return speed;
    }

    public Course getCourse() {
        return course;
    }

    public Task getTask() {
        return task;
    }
}
