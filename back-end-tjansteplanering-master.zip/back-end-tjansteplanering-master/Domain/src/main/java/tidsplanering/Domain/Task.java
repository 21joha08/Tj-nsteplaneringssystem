package tidsplanering.Domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Task implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String timescope;

    @Column(nullable = false)
    private String division;

    @Column(nullable = false)
    private String project;

    @Column(nullable = false)
    private String financier;

    @Column(nullable = false)
    private String activity;

    @Column(nullable = false)
    private double timeResource;

    @Column(nullable = false)
    private double budget;

    @Column(nullable = false)
    private int selected;

    @Column(nullable = false)
    private int isWork;

    @Column(nullable = false)
    private int isVacation;

    @Column(nullable = false)
    private int isResearch;

    @Column(nullable = false)
    private int isFundedExternally;

    @Column(nullable = false)
    private int isCancelled;

    @Column(nullable = false)
    private int isHandled;

    @Column(nullable = false)
    private String note;

    public Long getId() {
        return id;
    }

    public String getTimescope() {
        return timescope;
    }

    public String getDivision() {
        return division;
    }

    public String getProject() {
        return project;
    }

    public String getFinancier() {
        return financier;
    }

    public String getActivity() {
        return activity;
    }

    public double getTimeResource() {
        return timeResource;
    }

    public double getBudget() {
        return budget;
    }

    public int getSelected() {
        return selected;
    }

    public int getIsWork() {
        return isWork;
    }

    public int getIsVacation() {
        return isVacation;
    }

    public int getIsResearch() {
        return isResearch;
    }

    public int getIsFundedExternally() {
        return isFundedExternally;
    }

    public int getIsCancelled() {
        return isCancelled;
    }

    public int getIsHandled() {
        return isHandled;
    }

    public String getNote() {
        return note;
    }

}
