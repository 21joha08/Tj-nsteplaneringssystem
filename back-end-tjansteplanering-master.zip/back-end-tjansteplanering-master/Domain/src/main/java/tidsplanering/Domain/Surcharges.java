package tidsplanering.Domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Surcharges implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private int year;

    @Column(nullable = false)
    private double LKP;
    @Column(nullable = false)
    private double OHGU;

    @Column(nullable = false)
    private double OHFO;

    public Long getId() {
        return id;
    }

    public int getYear() {
        return year;
    }

    public double getLKP() {
        return LKP;
    }

    public double getOHGU() {
        return OHGU;
    }

    public double getOHFO() {
        return OHFO;
    }

}
