package tidsplanering.Domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Course implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String courseCode; // Kurskod ex. DVG506

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private double credits;

    @Column
    private String subject;

    @Column(nullable = false)
    private int department;

    @Column(nullable = false)
    private int subDivision;

    public Long getId() {
        return id;
    }

    public String getCourseId() {
        return courseCode;
    }

    public String getName() {
        return name;
    }

    public double getCredits() {
        return credits;
    }

    public String getSubject() {
        return subject;
    }

    public int getDepartment() {
        return department;
    }

    public int getSubDivision() {
        return subDivision;
    }

}
