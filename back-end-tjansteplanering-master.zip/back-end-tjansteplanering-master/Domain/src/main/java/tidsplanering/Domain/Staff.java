package tidsplanering.Domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
public class Staff implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String SSN;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String affiliationCode;

    @Column(nullable = false)
    private String affiliation;

    @Column(nullable = false)
    private double dutyDegree;

    @Transient
    private List<Double> workLoad;

    @Transient
    private List<CourseInstance> courses;

    @Transient
    private List<Project> projects;


    public List<CourseInstance> getCourseInstances() {
        return courses;
    }

    public void setCoursesInstances(List<CourseInstance> courses) {
        this.courses = courses;
    }

    public void setProjects(List<Project> projects) {
        this.projects = projects;
}

    public List<Project> getProjects() {
        return projects;
    }

    public Long getId() {
        return id;
    }

    public String getSSN() {
        return SSN;
    }

    public String getName() {
        return name;
    }

    public String getAffiliationCode() {
        return affiliationCode;
    }

    public String getAffiliation() {
        return affiliation;
    }

    public double getDutyDegree() {
        return dutyDegree;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setSSN(String SSN) {
        this.SSN = SSN;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAffiliationCode(String affiliationCode) {
        this.affiliationCode = affiliationCode;
    }

    public void setAffiliation(String affiliation) {
        this.affiliation = affiliation;
    }

    public void setDutyDegree(double dutyDegree) {
        this.dutyDegree = dutyDegree;
    }
    public List<Double> getWorkLoad() {
        return workLoad;
    }

    public void setWeeklyWorkLoadForYear(List<Double> workLoad) {
        this.workLoad = workLoad;
    }



}