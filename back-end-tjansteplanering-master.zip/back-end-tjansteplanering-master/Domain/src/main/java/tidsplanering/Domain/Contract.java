package tidsplanering.Domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Contract implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String timeScope;

    @Column(nullable = false)
    private double dutyDegree;

    @Column(nullable = false)
    private int salary;

    @Column(nullable = false)
    private String note;

    @Column(nullable = false)
    private boolean isMonthlyEmployed;

    @Column(nullable = false)
    private boolean isHourlyEmployed;

    @Column(nullable = false)
    private boolean isConsultant;

    @Column
    private String academicDegree;

    @Column
    private String academicPosition;

    @ManyToOne
    private Staff staff;

    public Long getId() {
        return id;
    }

    public String getTimeScope() {
        return timeScope;
    }

    public double getDutyDegree() {
        return dutyDegree;
    }

    public int getSalary() {
        return salary;
    }

    public String getNote() {
        return note;
    }

    public boolean isMonthlyEmployed() {
        return isMonthlyEmployed;
    }

    public boolean isHourlyEmployed() {
        return isHourlyEmployed;
    }

    public boolean isConsultant() {
        return isConsultant;
    }

    public String getAcademicDegree() {
        return academicDegree;
    }

    public String getAcademicPosition() {
        return academicPosition;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setTimeScope(String timeScope) {
        this.timeScope = timeScope;
    }

    public void setDutyDegree(double dutyDegree) {
        this.dutyDegree = dutyDegree;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public void setMonthlyEmployed(boolean monthlyEmployed) {
        isMonthlyEmployed = monthlyEmployed;
    }

    public void setHourlyEmployed(boolean hourlyEmployed) {
        isHourlyEmployed = hourlyEmployed;
    }

    public void setConsultant(boolean consultant) {
        isConsultant = consultant;
    }

    public void setAcademicDegree(String academicDegree) {
        this.academicDegree = academicDegree;
    }

    public void setAcademicPosition(String academicPosition) {
        this.academicPosition = academicPosition;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }
}
