package tidsplanering.Domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class YearGroup implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Curriculum curriculum;

    @Column
    private int startYear;

    @Column
    private int admitted;

    @Column
    private double retention;

    public Long getId() {
        return id;
    }

    public Curriculum getCurriculum() {
        return curriculum;
    }

    public int getStartYear() {
        return startYear;
    }

    public int getAdmitted() {
        return admitted;
    }

    public double getRetention() {
        return retention;
    }

}
