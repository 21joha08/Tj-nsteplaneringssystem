package tidsplanering.Domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Curriculum implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Program program;

    @Column(nullable = false)
    private int rev;

    @Column(nullable = false)
    private String revDate;

    @Column(nullable = false)
    private String name;

    public Long getId() {
        return id;
    }

    public Program getProgram() {
        return program;
    }

    public int getRev() {
        return rev;
    }

    public String getRevDate() {
        return revDate;
    }

    public String getName(){
        return name;
    }
}
