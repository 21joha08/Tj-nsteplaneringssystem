package tidsplanering.Domain;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

public class Timescope implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long startms;

    @Column(nullable = false)
    private Long endms;

    public Long getId() {
        return id;
    }

    public Long getStartms() {
        return startms;
    }

    public Long getEndms() {
        return endms;
    }
}
