package tidsplanering.Domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class CurriculumCourseContext implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Curriculum curriculum;

    @ManyToOne
    private Course course;

    @Column(nullable = false)
    private double speed;

    @Column(nullable = false)
    private int year;

    @Column(nullable = false)
    private int period;

    public Long getId() {
        return id;
    }

    public Curriculum getCurriculum() {
        return curriculum;
    }

    public Course getCourse() {
        return course;
    }

    public double getSpeed() {
        return speed;
    }

    public int getYear() {
        return year;
    }

    public int getPeriod() {
        return period;
    }
}
