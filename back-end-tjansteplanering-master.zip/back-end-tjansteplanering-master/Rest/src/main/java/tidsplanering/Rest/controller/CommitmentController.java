package tidsplanering.Rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import tidsplanering.Business.CommitmentService;
import tidsplanering.Domain.Commitment;
import tidsplanering.Domain.Department;
import tidsplanering.Domain.Staff;

import java.time.LocalDate;
import java.util.List;


@RestController
@RequestMapping("commitment")
public class CommitmentController {

    private final CommitmentService service;

    @Autowired
    public CommitmentController(CommitmentService service) {
        this.service = service;
    }

    /**
     * Retrieves all Commitment entities.
     *
     * @return List of Commitment entities.
     */
    @GetMapping("getAll")
    public List<Commitment> getAllCommitment() {
        return service.getAllCommitment();
    }

    /**
     * Retrieves Commitment entities for a specific staff member.
     *
     * @param staffId The ID of the staff member.
     * @return List of Commitment entities for the specified staff member.
     */
    @GetMapping("staff/get")
    public List<Commitment> getCommitmentByStaffId(@RequestParam(value = "staff-id") Long staffId) {
        return service.getCommitments(staffId);
    }

    /**
     * Calculates the workload for a staff member in a specific year.
     *
     * @param id   The ID of the staff member.
     * @param year The year for which workload needs to be calculated.
     * @return List of Double representing the total hours worked by the staff member in the specified year.
     */
    @GetMapping("getWorkloadPerStaff")
    public List<Double> calculateWorkloadForStaffInYear(
            @RequestParam(value = "staff-id") Long id,
            @RequestParam(value = "year") int year) {

        return service.calculateTotalHoursWorkedForStaffInYear(id, year);
    }

    /**
     * Retrieves information for all staff members with a specific affiliation code on a given date.
     * Each staff has a list of workload, courses and projects for the selected year/date.
     *
     * @param date            The date for which information is required.
     * @param affiliationCode The affiliation code used to filter staff members.
     * @return List of Staff entities with information for the specified date and affiliation code.
     */
    @GetMapping("getInfoForAllStaffWithCode")
    public List<Staff> getStuffForAllStaff(
            @RequestParam(value = "date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam(value = "code") String affiliationCode) {
        return service.getStuffForAllStaff(date, affiliationCode);
    }

    /**
     * Retrieves workload information for all departments on a given date.
     *
     * @param date The date for which department workload information is required.
     * @return List of Department entities with workload information for the specified date.
     */
    @GetMapping("getDepartmentInfoByYear")
    public List<Department> getWorkLoadForDepartment(
            @RequestParam(value = "date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return service.getDepartmentInfoByYear(date);
    }
}
