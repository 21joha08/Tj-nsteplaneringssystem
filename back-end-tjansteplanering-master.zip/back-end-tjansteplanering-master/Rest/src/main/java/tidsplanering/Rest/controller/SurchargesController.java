package tidsplanering.Rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tidsplanering.Business.SurchargesService;
import tidsplanering.Domain.Surcharges;

import java.util.List;

@RestController
@RequestMapping("surcharges")
public class SurchargesController {
    private final SurchargesService service;

    @Autowired
    public SurchargesController(SurchargesService service) {
        this.service = service;
    }

    /**
     * Retrieves all Surcharges entities.
     *
     * @return List of Surcharges entities.
     */
    @GetMapping("getAll")
    public List<Surcharges> getAllSurcharges(){
        return service.getAllSurcharges();
    }
}
