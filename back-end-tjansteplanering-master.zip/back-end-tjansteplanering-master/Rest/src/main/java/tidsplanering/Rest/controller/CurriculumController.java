package tidsplanering.Rest.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tidsplanering.Business.CurriculumService;
import tidsplanering.Domain.Curriculum;

import java.util.List;

@RestController
@RequestMapping("curriculum")
public class CurriculumController {
    private final CurriculumService service;

    @Autowired
    public CurriculumController(CurriculumService service) {
        this.service = service;
    }

    /**
     * Retrieves all Curriculum entities.
     *
     * @return List of Curriculum entities.
     */
    @GetMapping("getAll")
    public List<Curriculum> getAllCourseInstance(){
        return service.getAllCurriculum();
    }
}
