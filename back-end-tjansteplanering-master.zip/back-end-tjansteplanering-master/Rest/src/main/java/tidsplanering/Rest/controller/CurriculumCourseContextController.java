package tidsplanering.Rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tidsplanering.Business.CurriculumCourseContextService;
import tidsplanering.Domain.CurriculumCourseContext;

import java.util.List;

@RestController
@RequestMapping("CurriculumCourseContext")
public class CurriculumCourseContextController {

    private final CurriculumCourseContextService service;


    @Autowired
    public CurriculumCourseContextController(CurriculumCourseContextService service) {
        this.service = service;
    }

    /**
     * Retrieves all CurriculumCourseContext entities.
     *
     * @return List of CurriculumCourseContext entities.
     */
    @GetMapping("getAll")
    public List<CurriculumCourseContext> getAllCurriculumCourseContext(){
        return service.getAllCurriculumCourseContext();
    }
}
