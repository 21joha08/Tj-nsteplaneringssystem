package tidsplanering.Rest.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import tidsplanering.Business.StaffService;
import tidsplanering.Domain.Staff;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("staff")
public class StaffController {

    private final StaffService service;

    @Autowired
    public StaffController(StaffService service) {
        this.service = service;
    }

    /**
     * Retrieves all Staff entities.
     *
     * @return List of Staff entities.
     */
    @GetMapping("getAll")
    public List<Staff> getAllStaff() {
        return service.getAllStaff();
    }

    /**
     * Retrieves a Staff entity by its ID.
     *
     * @param staffId The ID of the staff member.
     * @return Optional containing the Staff entity with the specified ID, or an empty Optional if not found.
     */
    @GetMapping("getById")
    public Optional<Staff> getById(@RequestParam(value = "staff-id") Long staffId){
        return service.getById(staffId);
    }

}