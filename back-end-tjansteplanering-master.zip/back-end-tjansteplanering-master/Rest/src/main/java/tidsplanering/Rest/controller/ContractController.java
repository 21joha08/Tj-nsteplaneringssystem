package tidsplanering.Rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import tidsplanering.Business.ContractService;
import tidsplanering.Domain.Contract;
import java.util.List;

@RestController
@RequestMapping("contract")
public class ContractController {

    private final ContractService service;

    @Autowired
    public ContractController(ContractService service) {
        this.service = service;
    }

    /**
     * Retrieves all Contract entities.
     *
     * @return List of Contract entities.
     */
    @GetMapping("getAll")
    public List<Contract> getAllContract() {
        return service.getAllContract();
    }

    /**
     * Retrieves Contract entities for a specific staff member.
     *
     * @param staffId The ID of the staff member.
     * @return List of Contract entities for the specified staff member.
     */
    @GetMapping("staff/get")
    public List<Contract> getContractsByStaffId(@RequestParam(value = "staff-id") Long staffId) {
        return service.getContracts(staffId);
    }

}