package tidsplanering.Rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import tidsplanering.Business.ProjectService;
import tidsplanering.Domain.Project;

import java.util.List;

@RestController
@RequestMapping("project")
public class ProjectController {

    private final ProjectService service;

    @Autowired
    public ProjectController(ProjectService service){
        this.service = service;
    }

    /**
     * Retrieves all Project entities.
     *
     * @return List of Project entities.
     */
    @GetMapping("getAll")
        public List<Project> getAllProject(){
            return service.getAllProject();
        }

    /**
     * Retrieves Project entities for a specific year.
     *
     * @param year The year for which Project entities are to be retrieved.
     * @return List of Project entities for the specified year, or null if the year is before 2015.
     */
    @GetMapping("getByYear")
        public List<Project> getProjectsByYear(@RequestParam(value = "year") int year){
        if(year>2014)
                return service.getProjectsByYear(year);
        else
            return null;
        }


}
