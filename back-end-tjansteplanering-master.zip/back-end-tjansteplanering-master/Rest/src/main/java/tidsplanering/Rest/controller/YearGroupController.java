package tidsplanering.Rest.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tidsplanering.Business.YearGroupService;
import tidsplanering.Domain.YearGroup;

import java.util.List;
@RestController
@RequestMapping("yeargroup")
public class YearGroupController {

    private final YearGroupService service;

    @Autowired
    public YearGroupController(YearGroupService service){
        this.service = service;
    }

    /**
     * Retrieves all YearGroup entities.
     *
     * @return List of YearGroup entities.
     */
    @GetMapping("getAll")
        public List<YearGroup> getAllYearGroup(){
            return service.getAllYearGroup();
        }
    }

