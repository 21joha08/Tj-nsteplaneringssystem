package tidsplanering.Rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import tidsplanering.Business.CourseInstanceService;
import tidsplanering.Domain.CourseInstance;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("courseInstance")
public class CourseInstanceController {

    private final CourseInstanceService service;

    @Autowired
    public CourseInstanceController(CourseInstanceService service) {
        this.service = service;
    }

    /**
     * Retrieves all CourseInstance entities.
     *
     * @return List of CourseInstance entities.
     */
    @GetMapping("getAll")
    public List<CourseInstance> getAllCourseInstance(){
        return service.getAllCourseInstance();
    }

    /**
     * Retrieves CourseInstance entities for a specific year.
     *
     * @param year The year for which CourseInstance entities are to be retrieved.
     * @return List of CourseInstance entities for the specified year, or null if the year is before 2015.
     */
    @GetMapping("getByYear")
    public List<CourseInstance> getCourseInstanceByYear(@RequestParam(value = "year") int year) {
        if(year>2014)
            return service.getCourseInstancesByYear(year);
        else
            return null;
    }
}
