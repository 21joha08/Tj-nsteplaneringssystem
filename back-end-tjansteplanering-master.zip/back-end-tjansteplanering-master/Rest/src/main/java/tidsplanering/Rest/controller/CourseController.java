package tidsplanering.Rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tidsplanering.Business.CourseService;
import tidsplanering.Domain.Course;

import java.util.List;

@RestController
@RequestMapping("course")
public class CourseController {

    private final CourseService service;

    @Autowired
    public CourseController(CourseService service) {
        this.service = service;
    }

    /**
     * Retrieves all Course entities.
     *
     * @return List of Course entities.
     */
    @GetMapping("getAll")
    public List<Course> getAllCourse() {
        return service.getAllCourse();
    }

}

