package tidsplanering.Rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tidsplanering.Business.ProgramService;
import tidsplanering.Domain.Program;

import java.util.List;


@RestController
@RequestMapping("program")
public class ProgramController {

    private final ProgramService service;


    @Autowired
    public ProgramController(ProgramService service) {
        this.service = service;
    }

    /**
     * Retrieves all Program entities.
     *
     * @return List of Program entities.
     */
    @GetMapping("getAll")
    public List<Program> getAllProgram() {
        return service.getAllProgram();
    }
}
