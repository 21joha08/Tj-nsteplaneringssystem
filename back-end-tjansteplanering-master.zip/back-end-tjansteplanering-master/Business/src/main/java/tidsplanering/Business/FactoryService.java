package tidsplanering.Business;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FactoryService {


    public static <T> List<T> filterByYear(List<T> items, int selectedYear, TimeScopeExtractor<T> timeScopeExtractor) {
        return items.stream()
                .filter(item -> isWithinYear(timeScopeExtractor.extractTimeScope(item), selectedYear))
                .collect(Collectors.toList());
    }

    private static boolean isWithinYear(String timeScope, int selectedYear) {
        List<LocalDate> dateRange = convertTimeScopeToLocalDate(timeScope);
        return dateRange.get(0).getYear() <= selectedYear && dateRange.get(1).getYear() >= selectedYear;
    }

    public static List<LocalDate> convertTimeScopeToLocalDate(String timeScope) {

        List<LocalDate> listOfStartAndEndDate = new ArrayList<>();

        LocalDate desiredStartDate = LocalDate.of(2000 +
                        Integer.parseInt(timeScope.substring(0, 2)),
                Integer.parseInt(timeScope.substring(2, 4)),
                Integer.parseInt(timeScope.substring(4, 6)));

        LocalDate desiredEndDate = LocalDate.of(2000 +
                        Integer.parseInt(timeScope.substring(7, 9)),
                Integer.parseInt(timeScope.substring(9, 11)),
                Integer.parseInt(timeScope.substring(11, 13)));

        listOfStartAndEndDate.add(desiredStartDate);
        listOfStartAndEndDate.add(desiredEndDate);

        // { {startDate}, {endDate} }
        return listOfStartAndEndDate;
    }

    public interface TimeScopeExtractor<T> {
        String extractTimeScope(T item);
    }
}
