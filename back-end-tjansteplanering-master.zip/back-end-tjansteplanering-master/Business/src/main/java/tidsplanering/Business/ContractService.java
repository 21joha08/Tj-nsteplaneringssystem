package tidsplanering.Business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tidsplanering.Domain.Contract;
import tidsplanering.Repository.ContractRepository;
import java.util.List;

@Service
public class ContractService {

    private final ContractRepository contractRepository;

    @Autowired
    public ContractService(ContractRepository contractRepository) {
        this.contractRepository = contractRepository;
    }

    public List<Contract> getAllContract() {
        return contractRepository.findAll();
    }

    public List<Contract> getContracts(Long staffId) {
        return contractRepository.findByStaffId(staffId);
    }

    public List<Contract> getContractByStaffIdAndYear(Long staffId, int year) {
        return contractRepository.findByStaffIdAndTimeScopeStartingWith(staffId, String.valueOf(year).substring(2,4));
    }

    public List<Contract> getContractsByAffiliationCode(String affiliationCode) {
        return contractRepository.findByStaff_AffiliationCode(affiliationCode);
    }

}
