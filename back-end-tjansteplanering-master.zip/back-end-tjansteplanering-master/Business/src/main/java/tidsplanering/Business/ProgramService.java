package tidsplanering.Business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tidsplanering.Domain.Program;
import tidsplanering.Repository.ProgramRepository;
import java.util.List;

@Service
public class ProgramService {

    private final ProgramRepository programRepository;

    @Autowired
    public ProgramService(ProgramRepository programRepository){
        this.programRepository = programRepository;
    }

    public List<Program> getAllProgram(){
        return programRepository.findAll();
    }
}
