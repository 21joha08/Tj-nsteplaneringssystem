package tidsplanering.Business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import tidsplanering.Domain.*;
import tidsplanering.Repository.CommitmentRepository;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import static java.time.temporal.ChronoUnit.DAYS;


@Service
public class CommitmentService {

    private final CommitmentRepository commitmentRepository;
    private final ContractService contractService;
    private final StaffService staffService;
    private final ProjectService projectService;
    private final CourseInstanceService courseInstanceService;

    @Autowired
    public CommitmentService(CommitmentRepository commitmentRepository, @Lazy ContractService contractService,
                             @Lazy StaffService staffService, @Lazy CourseInstanceService courseInstanceService, @Lazy ProjectService projectService) {
        this.commitmentRepository = commitmentRepository;
        this.contractService = contractService;
        this.staffService = staffService;
        this.courseInstanceService = courseInstanceService;
        this.projectService = projectService;
    }

    public List<Commitment> getAllCommitment() {
        return commitmentRepository.findAll();
    }

    public List<Commitment> getCommitments(Long staffId) {

        return commitmentRepository.findByStaffId(staffId);
    }

    public List<Commitment> getCommitmentsByStartYear(int year) {
        return commitmentRepository.findByTimeScopeStartingWith(String.valueOf(year).substring(2, 4));
    }

    public List<Commitment> getStaffCommitmentsForYear(Long staffId, int year) {
        return commitmentRepository.findByStaffIdAndTimeScopeStartingWith(staffId, String.valueOf(year).substring(2, 4));
    }


    public List<Commitment> filterCommitmentsByYear(List<Commitment> commitments, int selectedYear) {
        return FactoryService.filterByYear(commitments, selectedYear, Commitment::getTimeScope);
    }

    public List<Double> calculateTotalHoursWorkedForStaffInYear(Long staffId, int year) {
        List<Double> workloads = new ArrayList<>();
        List<Double> test = getStaffHeatMapValuesForYear(staffId, LocalDate.ofYearDay(year, 1));
        List<Commitment> commitments = commitmentRepository.findByStaffIdAndTimeScopeStartingWith(staffId, String.valueOf(year).substring(2, 4));
        double avgWorkload = 0;
        double totalHoursWorked = 0.0;
        for (Commitment commitment : commitments) {
            totalHoursWorked += commitment.getTimeResource();
        }

        for (Double workload : test) {
            avgWorkload += workload;
        }
        workloads.add(totalHoursWorked);
        workloads.add(totalHoursWorked / 24);
        DecimalFormat df = new DecimalFormat("#.##", new DecimalFormatSymbols(Locale.ENGLISH));
        df.setRoundingMode(RoundingMode.HALF_UP);
        double roundedWorkLoad = Double.parseDouble(df.format(avgWorkload / 52));
        workloads.add(roundedWorkLoad);

        double totalDutyDegree = 0;
        List<Contract> contracts = contractService.getContractByStaffIdAndYear(staffId, year);
        for (Contract contract : contracts) {
            totalDutyDegree += contract.getDutyDegree();
        }
        totalDutyDegree = totalDutyDegree / contracts.size();
        workloads.add(totalDutyDegree);
        return workloads;
    }



    public List<Commitment> checkValidCommitmentsOnDay(List<Commitment> yearlyCommitments,
                                                       List<List<LocalDate>> yearlyTimesScopes,
                                                       LocalDate day) {
        if (yearlyCommitments == null || yearlyTimesScopes == null)
            return null;

        List<Commitment> todaysCommitments = new ArrayList<>();

        int i = 0;
        for (List<LocalDate> timeScope : yearlyTimesScopes) {
            if (day.isAfter(timeScope.get(0)) &&
                    day.isBefore(timeScope.get(1))) {
                todaysCommitments.add(yearlyCommitments.get(i));
            }
            i++;
        }
        return todaysCommitments;
    }


    private double getActiveDutyDegree(List<Contract> contracts, LocalDate todaysDate) {
        double activeDutyDegree = 0;

        if (contracts == null || contracts.isEmpty())
            return 0;

        for (Contract contract : contracts) {
            List<LocalDate> contractTimeScope = FactoryService.convertTimeScopeToLocalDate(contract.getTimeScope());
            if (todaysDate.isAfter(contractTimeScope.get(0))
                    && todaysDate.isBefore(contractTimeScope.get(1))) {
                activeDutyDegree = contract.getDutyDegree();
            }
        }

        return activeDutyDegree;
    }

    public double calculateTimeResource(List<Commitment> todaysCommitments) {
        double totalTimeResourceForDay = 0;
        int days = 0;

        for (Commitment commitment : todaysCommitments) {
            List<LocalDate> temp = FactoryService.convertTimeScopeToLocalDate(commitment.getTimeScope());

            days = (int) DAYS.between(temp.get(0), temp.get(1)) + 1;

            totalTimeResourceForDay += ((double) commitment.getTimeResource() / days);
        }
        return totalTimeResourceForDay;
    }

    public List<Double> getStaffHeatMapValuesForYear(Long staffId, LocalDate date) {
        List<Commitment> staffYearlyCommitments = filterCommitmentsByYear(commitmentRepository.findAllByStaffId(staffId),
                date.getYear());
        List<List<LocalDate>> allTimeScopesInYear = new ArrayList<>();

        for (Commitment commitment : staffYearlyCommitments) {
            allTimeScopesInYear.add(FactoryService.convertTimeScopeToLocalDate(commitment.getTimeScope()));
        }

        List<Contract> contracts = contractService.getContracts(staffId);

        List<Double> heatValues = new ArrayList<>();
        final double fullTimeHoursWeekly = 38.30769230769231;

        int dayOfYear = 1;
        int week = 1;
        boolean leapYear = date.isLeapYear();
        int weeksInYear = 52;


        // Adjust for 53 weeks
        if ((LocalDate.ofYearDay(date.getYear(), 1).getDayOfWeek() == DayOfWeek.WEDNESDAY) ||
                (LocalDate.ofYearDay(date.getYear(), 1).getDayOfWeek() == DayOfWeek.THURSDAY)) {
            weeksInYear = 53;
        }

        for (; week <= weeksInYear; week++) {
            double weeklyHoursExpected = 0;
            double weeklyHoursActual = 0;
            int daysInWeek = 7;

            if (week == 1) {
                daysInWeek = 8 - LocalDate.ofYearDay(date.getYear(), 1).getDayOfWeek().getValue();
            } else if (week == weeksInYear) {
                int lastDayOfYear = leapYear ? 366 : 365;
                daysInWeek = lastDayOfYear - dayOfYear;
            }

            for (int day = 1; day <= daysInWeek; day++) {
                if (dayOfYear > (leapYear ? 366 : 365)) {
                    break; // Prevents exceeding the total number of days in the year
                }

                LocalDate currentDay = LocalDate.ofYearDay(date.getYear(), dayOfYear);
                List<Commitment> todaysCommitments = checkValidCommitmentsOnDay(staffYearlyCommitments,
                        allTimeScopesInYear, currentDay);

                if (todaysCommitments != null) {
                    weeklyHoursActual += calculateTimeResource(todaysCommitments);
                }
                weeklyHoursExpected += getActiveDutyDegree(contracts, currentDay) * 8;
                dayOfYear++; // Increment at the end of processing for the day
            }

            double weeklyWorkLoad = 0;
            if (weeklyHoursExpected > 0 && weeklyHoursActual > 0) {
                weeklyWorkLoad = (weeklyHoursActual / weeklyHoursExpected);
            }

            DecimalFormat df = new DecimalFormat("#.##", new DecimalFormatSymbols(Locale.ENGLISH));
            df.setRoundingMode(RoundingMode.HALF_UP);
            double roundedweeklyWorkLoad = Double.parseDouble(df.format(weeklyWorkLoad * 100));
            heatValues.add(roundedweeklyWorkLoad);
        }
        System.out.println("antal veckor: " + heatValues.size());
        System.out.println(dayOfYear);
        return heatValues;
    }

    public List<String> affiliationStringToList(String input) {

        return Arrays.asList(input.split("\\s+"));
    }

    public List<Staff> getStuffForAllStaff(LocalDate date, String affiliationCode) {
        List<Staff> staffList = getAllStaffByAffiliationCode(affiliationCode);

        String year = String.valueOf(date.getYear());


        for (Staff staff : staffList) {
            staff.setWeeklyWorkLoadForYear(getStaffHeatMapValuesForYear(staff.getId(), date));
            staff.setCoursesInstances(courseInstanceService.getCourseInstancesByCommitments(
                    getStaffCommitmentsForYear(staff.getId(), Integer.parseInt(year))));
            staff.setProjects(projectService.getProjectsByCommitments(getStaffCommitmentsForYear(staff.getId(), Integer.parseInt(year))));
        }

        return staffList;
    }

    private List<Staff> getAllStaffByAffiliationCode(String affiliationCode) {
        if (affiliationCode.isEmpty()) {
            return staffService.getAllStaff();
        } else {
            return staffService.getAllStaff().stream()
                    .filter(staff -> affiliationStringToList(staff.getAffiliationCode())
                            .contains(affiliationCode))
                    .collect(Collectors.toList());
        }
    }

    public List<Department> getDepartmentInfoByYear(LocalDate inputDate) {
        LocalDate date = inputDate;
        if (date == null) {
            date = LocalDate.of(2023, 1, 1);
        }

        List<Department> departmentList = new ArrayList<>();
        List<String> affiliationCodes = Arrays.asList("7411", "7414", "7415");

        for (String affiliationCode : affiliationCodes) {
            Department tempDepartment = new Department();
            tempDepartment.setName(affiliationCode);

            List<Staff> staffListByCode = getAllStaffByAffiliationCode(affiliationCode);
            List<List<Double>> weeklyWorkloads = new ArrayList<>();

            for (Staff staff : staffListByCode) {
                List<Double> weeklyWorkload = getStaffHeatMapValuesForYear(staff.getId(), date);
                weeklyWorkloads.add(weeklyWorkload);
            }

            List<Double> averageWorkloads = calculateAverageWorkloads(weeklyWorkloads, affiliationCode, date);
            tempDepartment.setWorkLoad(averageWorkloads);
            departmentList.add(tempDepartment);
        }

        return departmentList;
    }

    private List<Double> calculateAverageWorkloads(List<List<Double>> weeklyWorkloads, String code, LocalDate date) {
        List<Double> averageWorkloads = new ArrayList<>();

        int weeksInYear = 52;

        if ((LocalDate.ofYearDay(date.getYear(), 1).getDayOfWeek() == DayOfWeek.WEDNESDAY ||
                (LocalDate.ofYearDay(date.getYear(), 1).getDayOfWeek() == DayOfWeek.THURSDAY))) {
            weeksInYear = 53;

        }

        for (int week = 0; week < weeksInYear; week++) {
            double weeklyWorkloadSum = 0;

            for (List<Double> staffWeeklyWorkloads : weeklyWorkloads) {
                if (staffWeeklyWorkloads.size() > week) {
                    weeklyWorkloadSum += staffWeeklyWorkloads.get(week);
                }
            }

            int numberOfStaff = getActiveContractsByDateAndAffiliationCode(date, code);

            double averageWorkload = numberOfStaff == 0 ? 0 : weeklyWorkloadSum / numberOfStaff;

            DecimalFormat df = new DecimalFormat("#.##", new DecimalFormatSymbols(Locale.ENGLISH));
            df.setRoundingMode(RoundingMode.HALF_UP);
            double roundedweeklyWorkLoad = Double.parseDouble(df.format(averageWorkload));
            averageWorkloads.add(roundedweeklyWorkLoad);
        }

        return averageWorkloads;
    }

    private int getActiveContractsByDateAndAffiliationCode(LocalDate date, String code) {
        List<Staff> staffByCode = getAllStaffByAffiliationCode(code);

        // Flatten the list of contracts
        List<Contract> allContracts = staffByCode.stream()
                .map(staff -> contractService.getContracts(staff.getId()))
                .flatMap(List::stream)
                .toList();

        int activeContractsCount = 0;

        for (Contract contract : allContracts) {
            List<LocalDate> timeScopeDates = FactoryService.convertTimeScopeToLocalDate(contract.getTimeScope());

            LocalDate startDate = timeScopeDates.get(0);
            LocalDate endDate = timeScopeDates.get(1);

            // Check if the given date is within the time scope of the contract
            if (!date.isBefore(startDate) && !date.isAfter(endDate)) {
                activeContractsCount++;
            }
        }

        return activeContractsCount;
    }
}





