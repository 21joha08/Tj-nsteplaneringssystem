package tidsplanering.Business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tidsplanering.Domain.Staff;
import tidsplanering.Repository.StaffRepository;
import java.util.List;
import java.util.Optional;

@Service
public class StaffService {

    private final StaffRepository staffRepository;

    @Autowired
    public StaffService(StaffRepository staffRepository) {
        this.staffRepository = staffRepository;
    }

    public List<Staff> getAllStaff() {
        return staffRepository.findAllByOrderByNameAsc();
    }

    public Optional<Staff> getById(Long id){
        return staffRepository.findById(id);
    }


}