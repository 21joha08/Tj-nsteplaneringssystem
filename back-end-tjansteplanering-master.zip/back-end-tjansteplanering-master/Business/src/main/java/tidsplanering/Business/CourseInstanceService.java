package tidsplanering.Business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tidsplanering.Domain.*;
import tidsplanering.Repository.CourseInstanceRepository;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CourseInstanceService {
    private final CourseInstanceRepository repository;

    @Autowired
    public CourseInstanceService(CourseInstanceRepository repository) {
        this.repository = repository;
    }

    public List<CourseInstance> getAllCourseInstance(){
        return repository.findAll();
    }
    public List<CourseInstance> getCourseInstancesByYear(int year) {
        List<CourseInstance> courseInstances = repository.findAll();
        courseInstances = filterCourseInstancesByYear(courseInstances, year);

         return courseInstances;
    }

    public List<CourseInstance> filterCourseInstancesByYear(List<CourseInstance> courseInstances, int selectedYear) {
        return FactoryService.filterByYear(courseInstances, selectedYear, CourseInstance -> CourseInstance.getTask().getTimescope());
    }

    public List<CourseInstance> getCourseInstancesByCommitments(List<Commitment> commitments) {
        List<Task> tasks = commitments.stream()
                .map(Commitment::getTask)
                .collect(Collectors.toList());

        return repository.findAllByTaskIn(tasks);
    }

}
