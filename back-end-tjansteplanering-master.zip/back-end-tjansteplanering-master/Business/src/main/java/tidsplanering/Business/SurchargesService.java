package tidsplanering.Business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tidsplanering.Domain.Surcharges;
import tidsplanering.Repository.SurchargesRepository;
import java.util.List;

@Service
public class SurchargesService {

    private final SurchargesRepository surchargesRepository;

    @Autowired
    public SurchargesService(SurchargesRepository surchargesRepository) {
        this.surchargesRepository = surchargesRepository;
    }

    public List<Surcharges> getAllSurcharges() {
        return surchargesRepository.findAll();
    }
}
