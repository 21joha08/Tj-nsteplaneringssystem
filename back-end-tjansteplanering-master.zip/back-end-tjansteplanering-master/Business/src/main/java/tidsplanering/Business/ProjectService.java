package tidsplanering.Business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tidsplanering.Domain.Commitment;
import tidsplanering.Domain.CourseInstance;
import tidsplanering.Domain.Project;
import tidsplanering.Domain.Task;
import tidsplanering.Repository.ProjectRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProjectService {

    private final ProjectRepository projectRepository;

    @Autowired
    public ProjectService(ProjectRepository projectRepository){
        this.projectRepository = projectRepository;
    }

    public List<Project> getAllProject(){
        return projectRepository.findAll();
    }


    public List<Project> getProjectsByYear(int year) {
        List<Project> projects = projectRepository.findAll();
        projects = filterProjectsByYear(projects, year);

        return projects;
    }

    public List<Project> getProjectsByCommitments(List<Commitment> commitments) {
        List<Task> tasks = commitments.stream()
                .map(Commitment::getTask)
                .collect(Collectors.toList());
        return projectRepository.findAllByTaskIn(tasks);
    }

    public List<Project> filterProjectsByYear(List<Project> projects, int selectedYear) {
        return FactoryService.filterByYear(projects, selectedYear, Project -> Project.getTask().getTimescope());
    }
}
