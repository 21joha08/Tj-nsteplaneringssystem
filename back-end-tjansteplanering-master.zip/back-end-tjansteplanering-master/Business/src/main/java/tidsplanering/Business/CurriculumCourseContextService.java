package tidsplanering.Business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tidsplanering.Domain.CurriculumCourseContext;
import tidsplanering.Repository.CurriculumCourseContextRepository;
import java.util.List;

@Service
public class CurriculumCourseContextService {

    private final CurriculumCourseContextRepository repository;

    @Autowired
    public CurriculumCourseContextService(CurriculumCourseContextRepository repository) {
        this.repository = repository;
    }

    public List<CurriculumCourseContext> getAllCurriculumCourseContext(){
        return repository.findAll();
    }
}
