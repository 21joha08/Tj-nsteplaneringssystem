package tidsplanering.Business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tidsplanering.Domain.Curriculum;
import tidsplanering.Repository.CurriculumRepository;
import java.util.List;

@Service
public class CurriculumService {

    private final CurriculumRepository repository;

    @Autowired
    public CurriculumService(CurriculumRepository repository) {
        this.repository = repository;
    }

    public List<Curriculum> getAllCurriculum(){
        return repository.findAll();
    }
}
