package tidsplanering.Business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tidsplanering.Domain.YearGroup;
import tidsplanering.Repository.YearGroupRepository;
import java.util.List;

@Service
public class YearGroupService {

    private final YearGroupRepository yearGroupRepository;

    @Autowired
    public YearGroupService(YearGroupRepository yearGroupRepository){
        this.yearGroupRepository = yearGroupRepository;
    }

    public List<YearGroup> getAllYearGroup(){
        return yearGroupRepository.findAll();
    }
}
