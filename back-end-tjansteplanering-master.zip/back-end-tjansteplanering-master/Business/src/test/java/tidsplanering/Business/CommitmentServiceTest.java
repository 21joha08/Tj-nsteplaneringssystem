package tidsplanering.Business;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tidsplanering.Domain.Commitment;
import tidsplanering.Domain.Staff;
import tidsplanering.Repository.CommitmentRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


class CommitmentServiceTest {

    private CommitmentService commitmentService;

    private CommitmentRepository commitmentRepoMock;

    private ContractService contractServiceMock;

    private StaffService staffServiceMock;

    private CourseInstanceService courseInstanceServiceMock;

    @BeforeEach
    void setUp() {
        commitmentRepoMock = mock(CommitmentRepository.class);
        contractServiceMock = mock(ContractService.class);
        staffServiceMock = mock(StaffService.class);
        courseInstanceServiceMock = mock(CourseInstanceService.class);
        commitmentService = new CommitmentService(commitmentRepoMock, contractServiceMock, staffServiceMock, courseInstanceServiceMock, null);

    }

    @AfterEach
    void tearDown() {
        commitmentService = null;
        commitmentRepoMock = null;
        contractServiceMock = null;
        staffServiceMock = null;
        courseInstanceServiceMock = null;
    }

    @Test
    void testgetAllCommitment() {
        Long staffId = 22L;
        Staff staff = new Staff();
        staff.setId(staffId);
        staff.setName("John");

        Long staffId2 = 20L;
        Staff staff2 = new Staff();
        staff2.setId(staffId2);
        staff2.setName("Jonteeee");

        Commitment commitment = new Commitment();
        commitment.setId(1L);
        commitment.setStaff(staff);
        commitment.setNote("Jag gillar också hamburgare");

        Commitment commitment2 = new Commitment();
        commitment2.setId(2L);
        commitment2.setStaff(staff2);
        commitment2.setNote("Jag gillar också potatis");

        List<Commitment> expected = new ArrayList<>();
        expected.add(commitment);
        expected.add(commitment2);

        when(commitmentRepoMock.findAll()).thenReturn(expected);

        List<Commitment> actual = commitmentService.getAllCommitment();

        assertEquals(expected, actual);

        verify(commitmentRepoMock).findAll();
    }

    @Test
    void testgetCommitmentsByStaffId() {
        Long staffId = 22L;
        Staff staff = new Staff();
        staff.setId(staffId);
        staff.setName("John");

        Commitment commitment = new Commitment();
        commitment.setId(1L);
        commitment.setStaff(staff);
        commitment.setNote("Jag gillar också hamburgare");
        List<Commitment> expected = List.of(commitment);


        when(commitmentRepoMock.findByStaffId(staffId)).thenReturn(expected);

        List<Commitment> actual = commitmentService.getCommitments(staffId);

        assertEquals(expected, actual);

        verify(commitmentRepoMock).findByStaffId(staffId);

    }

    @Test
    void testConvertTimeScopeOfCommitmentToLocalDate() {
        String timeScope = "230101:231212";
        List<LocalDate> actual = FactoryService.convertTimeScopeToLocalDate(timeScope);

        List<LocalDate> expected = new ArrayList<>();
        expected.add(LocalDate.of(2023, 1, 1));
        expected.add(LocalDate.of(2023, 12, 12));

        assertEquals(expected, actual);
    }


    @Test
    void testFilterCommitmentsByYear() {
        List<Commitment> commitments = new ArrayList<>() {{
            add(new Commitment() {{
                setTimeScope("230101:230606");
            }}); // 2023
            add(new Commitment() {{
                setTimeScope("230630:231212");
            }}); // 2023
            add(new Commitment() {{
                setTimeScope("210101:211212");
            }}); // 2021
        }};

        int year = 2023;

        int expected = 2;
        int actual = commitmentService.filterCommitmentsByYear(commitments, year).size();
        assertEquals(expected, actual);

        year = 2021;
        expected = 1;
        actual = commitmentService.filterCommitmentsByYear(commitments, year).size();
        assertEquals(expected, actual);
    }


    @Test
    void testCheckValidCommitmentOnDay() {
        List<Commitment> commitments = new ArrayList<>() {{

            add(new Commitment() {{
                setTimeScope("230101:230606");
            }}); // 2023
            add(new Commitment() {{
                setTimeScope("230630:231212");
            }}); // 2023
            add(new Commitment() {{
                setTimeScope("230630:231212");
            }}); // 2023

        }};

        List<List<LocalDate>> allTimeScopesInYear = new ArrayList<>();

        for (Commitment commitment : commitments) {
            allTimeScopesInYear.add(FactoryService.convertTimeScopeToLocalDate(commitment.getTimeScope()));
        }

        int expected;
        int actual;

        LocalDate day = LocalDate.of(2023, 5, 12);
        expected = commitmentService.checkValidCommitmentsOnDay(commitments, allTimeScopesInYear, day).size();
        actual = 1;
        assertEquals(expected, actual);

        day = LocalDate.of(2023, 7, 7);
        expected = commitmentService.checkValidCommitmentsOnDay(commitments, allTimeScopesInYear, day).size();
        actual = 2;
        assertEquals(expected, actual);

        day = LocalDate.of(2023, 6, 7);
        expected = commitmentService.checkValidCommitmentsOnDay(commitments, allTimeScopesInYear, day).size();
        actual = 0;
        assertEquals(expected, actual);

    }

    @Test
    void testCalculateTimeResource() {

        List<Commitment> commitments = new ArrayList<>() {{

            add(new Commitment() {{
                setTimeScope("230101:230104");
                setTimeResource(20);
            }}); // 2023
            add(new Commitment() {{
                setTimeScope("230101:230102");
                setTimeResource(30);
            }}); // 2023

        }};

        double expected;
        double actual;

        actual = commitmentService.calculateTimeResource(commitments);
        expected = 20;

        assertEquals(expected, actual);

        commitments.add(new Commitment() {{
            setTimeScope("230101:230110");
            setTimeResource(100);
        }});
        actual = commitmentService.calculateTimeResource(commitments);
        expected = 30;

        assertEquals(expected, actual);

    }
}