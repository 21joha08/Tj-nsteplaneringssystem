package tidsplanering.Business;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tidsplanering.Domain.Contract;
import tidsplanering.Domain.Staff;
import tidsplanering.Repository.ContractRepository;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ContractServiceTest {

    private ContractService contractService;

    private ContractRepository contractRepoMock;

    @BeforeEach
    void setUp() {
        contractRepoMock = mock(ContractRepository.class);
        contractService = new ContractService(contractRepoMock);
    }

    @AfterEach
    void tearDown() {
        contractRepoMock = null;
        contractService = null;
    }

    @Test
    void getAllContract() {
        Long staffId = 22L;
        Staff staff = new Staff();
        staff.setId(staffId);
        staff.setName("K9");

        Long staffId2 = 1L;
        Staff staff2 = new Staff();
        staff2.setId(staffId2);
        staff2.setName("K10");

        Contract contract = new Contract();
        contract.setId(1L);
        contract.setStaff(staff);

        Contract contract2 = new Contract();
        contract2.setId(1L);
        contract2.setStaff(staff2);

        List<Contract> expected = new ArrayList<>();
        expected.add(contract);
        expected.add(contract2);

        when(contractRepoMock.findAll()).thenReturn(expected);

        List<Contract> actual = contractService.getAllContract();

        assertEquals(expected, actual);

        verify(contractRepoMock).findAll();

    }

    @Test
    void getContracts() {
        Long staffId = 22L;
        Staff staff = new Staff();
        staff.setId(staffId);
        staff.setName("K9");

        Contract contract = new Contract();
        contract.setId(1L);
        contract.setStaff(staff);

        List<Contract> expected = List.of(contract);

        when(contractRepoMock.findByStaffId(staffId)).thenReturn(expected);

        List<Contract> actual = contractService.getContracts(staffId);

        assertEquals(expected, actual);

        verify(contractRepoMock).findByStaffId(staffId);

    }
}